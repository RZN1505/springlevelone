package pro.bolshakov.geekbrains.dz2.service;

import pro.bolshakov.geekbrains.dz2.domain.Product;

import java.util.List;

public interface ProductDAOService {
    List<Product> getAll();
    Product getById(Long id);
    Product save(Product product);
}

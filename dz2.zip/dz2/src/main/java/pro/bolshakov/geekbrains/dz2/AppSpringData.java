/*package pro.bolshakov.geekbrains.dz2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import pro.bolshakov.geekbrains.dz2.service.ProductServiceImpl;

public class AppSpringData {

    private static ProductServiceImpl productService;

    public static void main(String[] args) {

        ApplicationContext context = new AnnotationConfigApplicationContext(SpringDataConfig.class);

        //ProductServiceImpl productService = context.getBean(ProductServiceImpl.class);

        //new ProductController(productService);

       // Product product = InitData.getProduct1();
        //System.out.println(product);

       // productService.save(product);
    }
}*/
